Thanks for downloading this themepack!

I hope you like it!

Consider visiting our discord server! https://dsc.gg/elixermc

My Discord: LoungeClown#3381